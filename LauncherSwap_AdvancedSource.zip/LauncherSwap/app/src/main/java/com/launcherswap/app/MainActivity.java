
package com.launcherswap.app;

import android.content.Intent;
import android.content.ComponentName;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scrollView = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        Button chooserBtn = new Button(this);
        chooserBtn.setText("Trigger Home Intent Chooser");
        chooserBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });
        layout.addView(chooserBtn);

        Button novaBtn = new Button(this);
        novaBtn.setText("Launch Nova Launcher Directly");
        novaBtn.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.teslacoilsw.launcher", "com.teslacoilsw.launcher.NovaLauncher"));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });
        layout.addView(novaBtn);

        Button settingsBtn = new Button(this);
        settingsBtn.setText("Open Default Apps Settings (if supported)");
        settingsBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_HOME_SETTINGS);
            try {
                startActivity(intent);
            } catch (Exception e) {
                intent = new Intent(Settings.ACTION_APPLICATION_SETTINGS);
                startActivity(intent);
            }
        });
        layout.addView(settingsBtn);

        Button launcherSettingsBtn = new Button(this);
        launcherSettingsBtn.setText("Open Installed Launchers List (Activity chooser)");
        launcherSettingsBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(intent, "Choose Launcher"));
        });
        layout.addView(launcherSettingsBtn);

        Button systemSettingsBtn = new Button(this);
        systemSettingsBtn.setText("Open Manage Apps Settings (Fallback)");
        systemSettingsBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS);
            startActivity(intent);
        });
        layout.addView(systemSettingsBtn);

        scrollView.addView(layout);
        setContentView(scrollView);
    }
}

package com.example.launcherredirect

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class LauncherRedirectService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString() ?: return

        if (packageName == "com.amazon.firelauncher") {
            val launchIntent = packageManager.getLaunchIntentForPackage("com.teslacoilsw.novalauncher")
            launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        }
    }

    override fun onInterrupt() {}
}